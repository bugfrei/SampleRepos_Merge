// Hans hat schonmal mit Modul 3 angefangen

console.log("Das ist Module 3");
for (var i = 1; i < 20; i+=2)
{
    console.log("Ungerade Zahl: " + i.toString());
}

console.log("Fertig");

