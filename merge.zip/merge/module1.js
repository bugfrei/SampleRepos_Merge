console.log("Das ist Modul 1");

for (var i = 0; i < 10; i++)
{
    console.log(i);
}

