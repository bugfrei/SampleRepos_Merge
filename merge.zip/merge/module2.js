// Hans arbeiter an diesem Modul
console.log("Das ist Modul 2");

for (var i = 10; i < 20; i++)
{
    console.log("Zahl: " + i.toString());
}

console.log("Das waren die Zahlen von Module 2");


